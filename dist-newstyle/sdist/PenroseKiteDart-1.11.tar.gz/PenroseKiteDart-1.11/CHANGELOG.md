# Revision history for PenroseKiteDart

## version 1.11

Significant changes to P3 tiling (rhombuses) and drawing P3 style.

- Renamed module TileLibP3 as Tgraph.Rhombuses

- Renamed some P3 functions, types, classes (for consistency)
   - P3_HalfTile renamed as HalfTile_P3
   - P3_Piece renamed as Piece_P3
   - P3_Patch renamed as Patch_P3
   - joinVectorP3 renamed as joinVector_P3
   - drawnEdgesP3 renamed as drawnEdges_P3
   - decompP2toP3 renamed as decompPatchP2toP3
   - decompP3toP2 renamed as decompPatchP3toP2
   - drawPieceP3  renamed as drawPiece_P3
   - drawjPieceP3 renamed as drawjPiece_P3 
   - drawJPieceP3 renamed as drawJPiece_P3
   - P3_Drawable renamed as Drawable_P3
   - P3_DrawableLabelled renamed as DrawableLabelled_P3
   - labelColourSizeP3 renamed as labelColourSize_P3
   - labelSizeP3 renamed as labelSize_P3
   - labelledP3 renamed as labelled_P3
   - drawP3With renamed as drawWith_P3
   - drawP3 renamed as draw_P3
   - drawjP3 renamed as drawj_P3
   - drawJP3 renamed as drawJ_P3
- Added
    - makeEVnewMap
    - checkConnectedNoCross
    - Tgraph_P3()
    - decomposeToRhombuses
    - decomposeToTgraph
    - decomposeRhombuses
    - tryComposeToRhombuses
    - quickComposeToRhombuses
    - TileFace_P3
    - tryConnectedNoCross_P3
    - tryComposeToFaces_P3
    - quickComposeToFaces_P3
    - faces_P3
    - maxV_P3
    - vertexSet_P3
    - faceVSet_P3
    - faceVs_P3
    - faceVList_P3
    - originV_P3
    - oppV_P3
    - wingV_P3
    - join_P3
    - isWide
    - isNarrow
    - dedges_P3
    - VPatch_P3(vLocs_P3,vpFaces_P3)
    - makeVP_P3
    - dropLabels_P3
    - convertVPatch_P3
    - convertVPatch
    - deformVPatch_P3
    - HalfTile_P3(LW,RW,LN,RN)
    - tileRep_P3
    - joinVector_P3
    - drawnEdges_P3
    - Piece_P3
    - decompPieceP2toP3
    - decompPieceP3toP2
    - Patch_P3
    - decompPatchP2toP3
    - decompPatchP3toP2
    - drawPiece_P3
    - drawjPiece_P3
    - drawJPiece_P3
    - fillOnlyPiece_P3
    - fillOnlyPieceWN
    - fillPieceWN
    - Drawable_P3(..)
    - draw_P3
    - drawj_P3
    - drawJ_P3
    - fillWN
    - fillNW
    - DrawableLabelled_P3(..)
    - labelSize_P3
    - labelled_P3
    - composeToRhombusProblem (in TgraphExamples)


## version 1.10.1

-  VPatch is now deformable

-  Added:
     deformVP (in Tgraph.Prelude), deformExample (in TgraphExamples)

-  Also Added:
     kiteOppCount, deuceMissingDart, jackMissingDart, queenMissingDart, aceMissingKite, queenOrKingMissingKite,
     chunking, centerRows, centerRows', arrangeRows'
  
-  Deprecated:
    kiteGaps (Renamed as deuceMissingDart)
    nonKDarts (Renamed as aceMissingKite)
    noTouchingDart (Renamed as jackMissingDart)
    queenMissingDarts (Renamed as queenMissingDart)
    kitesWingDartOrigin  (Renamed as queenOrKingMissingKite)
    arrangeRowsGap (Renamed as arrangeRows')
  
## version 1.10

- Possibly breaking change:
  - Redefined Piece to use a list of two vectors for the drawn edges instead of a single
  vector for the join edge.
  VPatch and Patch now transform correctly before and after drawing (linear transformations).
  (Previously only rotations, translations, and uniform scaling worked before drawing.)
  - The same changes have been made to P3_Piece in TileLibP3 so P3_Patch will transform correctly.
  - tileRepP3 has been removed (use drawnEdgesP3)

The following no longer use angles in their definition: drawnEdges, drawnEdgesP3, decompPieceP3toP2, decompPieceP2toP3, compChoices, compNChoices

The following do rely on angles so will not work as expected after a transformation that does not preserve angles: wholeTileEdges, leftFillPieceDK.

- Other changes:
  Added joinVectorP3 to TileLibP3
  Added testVPTransform to TgraphExamples

## version 1.9

- Possibly breaking changes:
   - Replaced type UpdateMap with new data type Updates (using two maps).
   - Renamed selector updateMap to updates (in ForceState)
   - partComposeDWI has a different type returning a Tgraph with the remainder faces
   - Renamed matchingLongE,matchingJoinE,matchingShortE to sharingLongE,sharingJoinE,sharingShortE
   - Change to DartWingInfo. Selector unMapped is changed to remaining. The remaining list now includes all kites without a dart wing at their oppV.
- Removed Deprecated:
   - partComposeFaces - use - (runTry . tryPartComposeFaces)
   - boundaryEdgeSet - use - boundaryESet
   - boundaryVertexSet - use - boundaryVSet
   - vertexFacesMap - use - (vertexFMap . IntSet.fromList)
   - dedgesFacesMap - use - dedgeFMap
   - boundaryEdgeFaces - use - boundaryEFaces
   - rotateBefore - use - (flip rotating)
   - alignAll - use - (map . alignXaxis)
   - alignBefore - use - (flip aligning)
   - makeAlignedVP  - use - alignedVP
   - tryOneStepForce - use - tryOneStep
   - recoverGraphF - use - (withForced recoverGraph)
   - boundaryStateF - use - (withForced boundaryState)
   - makeBoundaryStateF - use - (withForced makeBoundaryState)
   - initFSF - use - (withForced initFS)
   - relabelContig - use - (relabelFrom 1)
   - checkRelabelGraph - use - relabelGraph
   - smartRotateBefore - use - (flip smartRotating)
   - smartAlignBefore - use - (flip smartAligning)
   - drawTrackedTgraphAligned - use - (flip drawTrackedTgraphAligning)
   - drawTrackedTgraphRotated - use - (flip drawTrackedTgraphRotating)
   - allClashes - use - allTouching
- Other Changes
  - Added: quickCompose and quickPartCompose (approximations to compose and partCompose that do not use a force operation)
  - Added experimental tryForceAt
  - Added experimental tryGetDartWingInfoLocal
  - Added: verticesForBEs, vertexSetForEdges
  - deprecated noNewConflict (renamed as compatibleNew)
  - More laziness in BoundaryState (avoids vertex location calculation until any unsafe update)

## version 1.8.1

Fixed bug (introduced in 1.8) rotations and scales not behaving as described.

## version 1.8

- Possibly breaking change: The ForceState now carries an UpdateGenerator and Forcible class operations now assume defaultAllUGen or take the UpdateGenerator from the ForceState.
The Forcible class operations are now
  - tryInitFS (replacing tryInitFSWith)
  - tryFSOp (replacing tryFSOpWith, but tryFSOpWith is now defined in terms of tryFSOp.)
  - tryChangeBoundary (replacing tryChangeBoundaryWith)

  - No longer Exported: tryReviseUpdates, tryReviseFSWith, tryOneStepWith, tryInitFSWith, tryChangeBoundaryWith, tryDartAndKiteF, tryDartAndKiteForced, checkCasesDKF

- Other changes:
  - Introduced class HasGraph (instances Tgraph, BoundaryState, ForceState, and Forced versions of these)
  - Generalised recoverGraph (and many other functions now using HasGraph such as compose, decompose,...)
  - Reinstated nullGraph (with HasGraph constraint)
  - Introduced withForced, alignedVP, rotatedVP

  - Deprecated tryOneStepForce (RENAMED as tryOneStep) 
  - Deprecated recoverGraphF, boundaryStateF, makeBoundaryStateF, initFSF (now using withForced)
  - Deprecated makeAlignedVP (renamed as alignedVP)
  - Deprecated alignAll (use (map . alignXaxis))
  - superForce now produces Forced Tgraph (compose with forgetF to obtain Tgraph)


## version 1.7

Significant speed up of forcing.

- Possibly breaking change (internal representation change):
  - Added grid to BoundaryState with newtype (Grid a) defined in new module Tgraph.Grid.
    This provides much faster touching vertex checks. Grid is also used for touchingVertices.
  - Removed touchCheck

- Other changes

  - Added joinDashing', dashj', dashJ', defaultJoinDashSize
  - Added completeEdgeSet, bothDirSet
  - Exported tryOnBoundary, isBoundaryDE, isBoundaryV
  - Used smart on boundaryFDart.. and boundaryGap.. example figures.

## version 1.6.1

- Internal Representation change:
    - Changed type of BoundaryDedges in BoundaryState (constructors not exported)
       (This does not affect boundary or boundaryESet functions).
    - boundaryAt is much more efficient (using new representation for BoundaryDedges) and returns the two boundary directed edges in boundary direction order.

- Other changes:
    - Added nextBV and prevBV (efficient)
    - Added rotating, aligning, smartRotating, smartAligning, drawTrackedTgraphAligning, drawTrackedTgraphRotating, partComposeDWI.
    - Deprecated smartRotateBefore (Use (flip smartRotating))
    - Deprecated smartAlignBefore (Use (flip smartAligning))
    - Deprecated rotateBefore (Use (flip rotating))
    - Deprecated alignBefore (Use (flip aligning))
    - Deprecated drawTrackedTgraphAligned (Use (flip drawTrackedTgraphAligning))
    - Deprecated drawTrackedTgraphRotated (Use (flip drawTrackedTgraphRotating))
    - Deprecated partComposeFaces (now renamed as partComposeDWI)
    - Changed emphasizeFaces to use smartOn so only boundary joins are drawn (used in commonFaces)

## version 1.6
- Possibly breaking:

   - Replaced boundary in class HasFaces with boundaryESet (Set instead of list)
            (boundary now derived from boundaryESet)
   - Removed data constructor Relabelling from export
   - Renamed relabelGraph as uncheckedRelabelGraph
   - Renamed checkRelabelGraph as relabelGraph (now using unsafeDom check)
   - Renamed locateVertices as locateGraphVertices AND restricted to Tgraphs only.
   - No longer exporting locateVerticesGen
   - Removed oldGetDartWingInfo
   - Removed oldPartCompose
   - Removed partComposeFacesFrom (use partComposeFaces)

- Other changes:

   - Default implementations in Class HasFaces for boundaryESet, maxV, boundaryVFMap
   - Deprecated boundaryEdgeSet (use boundaryESet)
   - Deprecated boundaryVertexSet (use boundaryVSet)
   - Deprecated boundaryEdgeFaces (use boundaryEFaces)
   - Deprecated dedgesFacesMap (use dedgeFMap)
   - Deprecated vertexFacesMap (use vertexFMap . IntSet.fromList)
   - Added boundaryVSet, boundaryEFaces, dedgeFMap, vertexFMap
   - Added evalDedge, evalDedges, evalFace, evalFaces (for full evaluation)
   - Added unsafeDom (for use with relabellings)
   - Added faceCount
   - Added dedgeSet, missingRevSet
   - Added partComposeFaces
   - relabelAvoid now exported
   - relabelFrom now exported
   - relabelContig deprecated. Use (relabelFrom 1)
   - checkRelabelGraph deprecated. Use (relabelGraph)
   - Changed Tgraph definition so no record type used
     (this was hidden anyway but visible when a Tgraph was shown)

- Removed deprecated:

   - subVP Use (flip subFaces)
   - restrictVP Use (flip restrictTo)
   - restrictSmart Use smartOn
   - selectFacesVP Use (flip restrictTo)
   - removeFacesVP Use (flip removeFacesFromVP)
   - boundaryFaces Use boundaryVFaces or boundaryEFaces
   - pieceEdges Use drawnEdges
   - dashjPiece Use drawjPiece
   - dashjP3 Use drawjP3

## version 1.5.1

- possibly breaking:
    added boundaryVFMap to class HasFaces

- generalised:

    - boundaryJoinFaces
    - drawBoundaryJoins
    - drawJoinsFor

- added:

    - boundaryEFMap
    - smartOn (replacing deprecated restrictSmart)
    - restrictTo (replacing deprecated restrictVP)
    - subFaces (replacing deprecated subVP)
    - boundaryVFaces (replacing deprecated boundaryFaces)
    - boundaryEdgeFaces
    - removeFacesFromVP (replacing deprecated removeFacesVP)
    - removeVerticesFromVP
    - selectVerticesFromVP

- deprecated:

    - selectFacesVP
    - restrictSmart
    - restrictVP
    - subVP
    - boundaryFaces
    - removeFacesVP

- warning avoided for import of foldl'

- joinDashing changed appearance (no longer ultraThin by default)

- added: dashJOnly, drawJPiece, and drawJ 
(alongside dashjOnly, drawjPiece, and drawj which still use ultraThin) 

## version 1.5 2025-8-9

Changes to composing.

(When a Tgraph is not known to be forced,
composing now involves calculating the forced version to get accurate information
about boundary dart wings.  Previously only local information was used to classify
which could result in a dart wing being classified as unknown when non-local
information suggests otherwise).

This affects:
    compose,
    partCompose,
    tryPartCompose (new),
    tryPartComposeFaces (new),
    tryGetDartWingInfo (new)
    
This does not affect:
    composeF, 
    partComposeF, 
    getDartWingInfoForced, 
    partComposeFacesFrom (new)

removed:
    partComposeFaces, 
    partComposeFacesF,
    composedFaceGroups,
    getDartWingInfo (renamed as oldGetDartWingInfo)

The previous version of partCompose is renamed as oldPartCompose (for comparisons)

## version 1.4.5  -- 2025-8-3
added:
    class P3_DrawableLabelled (instances VPatch, Tgraph)
    with labelColourSizeP3, labelSizeP3, labelledP3

    drawjP3 (renamed from dashjP3)
    fillOnlyPieceDK
    drawjPiece (renamed from dashjPiece)
    drawnEdges (renamed from pieceEdges)

    decomposeFaces

exposed:
    P3_Patch, bothDir, missingRevs, extractLowestJoin

generalised:
    phiVMap

deprecated:
    dashjP3, dashjPiece, pieceEdges (all renamed)

## version 1.4.4  -- 2025-7-9

Fixed bug in remainder faces for new partComposeF

Added new module `TileLibP3` for drawing P3 tilings.
This is now included in `PKD` export list
with example `testRhombus` in module `TgraphExamples`.

## version 1.4.3  -- 2025-7-1

Fixed bug in `partComposing`.
(partCompFacesFrom was assuming forced to get remainders.)
This is now incorporated in partComposeFaces and partComposeFacesF
and partCompFacesFrom is now removed.

## version 1.4.2  -- 2025-7-1

DartWingInfo has an extra field (unMapped)

Improved composing performance (now a Strict module)
New: partCompFacesFrom (used instead of composeFaceGroups in composing)

## version 1.4.1  -- 2025-6-26
Force module is now Strict (significantly improves space usage)
(HalfTile, Decompose, Relabelling also made Strict
and Prelude StrictData)

ForceState now an instance of class HasFaces

New: boundaryEdgeFilter
  (used instead of boundaryFilter to simplify UFinders)


## version 1.4 -- 2025-6-12

Changed module Tgraphs to module Tgraph.Extras

### New HasFaces class

Introduced to define common functions for 
[TileFace], Tgraph, VPatch, BoundaryState, Forced

Breaking Name Changes for
    nullGraph -> nullFaces
    graphBoundary -> boundary
    facesBoundary -> boundary
    graphDedges -> dedges
    facesDedges  -> dedges
    facesVSet -> vertexSet
    facesMaxV -> maxV
    graphBoundaryVs -> boundaryVs
    boundaryVertexSet -> vertexSet
    facesEdges -> completeEdges
    graphEdges -> completeEdges
    boundaryLoopsG -> boundaryLoops
    graphEFMap -> buildEFMap

    Also changed selector in BoundaryState to boundaryDedges (but note boundary generalised)

Generalised (to use HasFaces)
    boundary
    faces
    maxV
    vertexSet
    boundaryVs
    internalEdges
    phiEdges
    nonPhiEdges
    vertexFacesMap
    dedgesFacesMap
    buildEFMap
    extractLowestJoin
    lowestJoin
    locateVertices
    locateVerticesGen
    touchingVertices
    boundaryEdgeSet
    commonBdry
    boundaryVertexSet
    internalVertexSet
    boundaryLoops
    evalFaces
    ldarts,rdarts,lkites,rkites, kites, darts
    crossingBVs
    crossingBoundaries
    connected
    defaultAlignment
    findEdgeLoops
    hasEdgeLoops
    conflictingDedges

Breaking: No longer exported:
findLoops, axisJoin, drawEdge (use drawLocatedEdge), drawEdges (use drawLocatedEdges),
crossingVertices, tryFindThirdV, makeGenerator (use newUpdateGenerator)

### Try changed
Changed the type for Try to use ShowS instead of String
(ShowS = String -> String)

New: failReport, failReports, tryAtLeastOne

Breaking:
   Occurrences of 
        Left s :: Try a
    need to be replaced by 
        failReport s 
    or
        Left (s<>)

An instance of Show(ShowS) is provided in order to show Try results

### Changes to Forced

Forced is no longer a Functor.

Instead, 4 specific safe cases for changing a Forced Forcible
(New)
recoverGraphF,boundaryStateF,makeBoundaryStateF,initFSF

Data constructor Forced is no longer exported but
(New)
labelAsForced :: a -> Forced a (for use only when the argument is known to be forced)

(New)
tryDartAndKiteF - version of tryDartAndKiteForced with explicitly forced results.
tryCheckCasesDKF, checkCasesDKF - special case to report any counter example found
when trying to add a dart and kite to a boundary edge of an explicitly Forced forcible.
 
Removed warning pragma for makeUncheckedTgraph

## version 1.3 -- 2025-5-19

(New)
Introduced newtype operator Forced
to enable restricting functions which require a forced argument.
Forced a is an explicitly forced version of a.

Breaking changes:

Removed: 
uncheckedCompose (use new composeF with explicitly Forced Tgraph)
uncheckedPartCompose (use new partComposeF with explicitly Forced Tgraph)

Changed types (to make use of Forced) for:
compForce
allCompForce
maxCompForce
boundaryVCovering
boundaryECovering
singleChoiceEdges

Removed deprecated: 
noFails (use runTry . concatFails)
colourMaybeDKG (use colourDKG with transparent)
fillMaybeDK (use fillDK with transparent)
fillMaybePieceDK (use fillPieceDK with transparent)

Renamed:
tryOneStepF is now tryOneStepForce

Other changes:

(New)
forgetF :: Forced a -> a (to unwrap explicitly Forced)
tryForceF (to create explicitly Forced)
forceF (to create explicitly Forced)
composeF :: Forced Tgraph -> Forced Tgraph
partComposeF :: Forced Tgraph -> ([TileFace], Forced Tgraph)

Added warning in PKD for makeUncheckedTgraph


## version 1.2.1 -- 2025-4-2

Added: drawBoundaryJoins, joinDashing

Renamed: drawEdge, drawEdges as drawLocatedEdge, drawLocatedEdges
Depracating: drawEdge, drawEdges

Generalised: colourDKG, fillDK, fillKD, fillPieceDK, fillOnlyPiece
to work with AlphaColours as well as Colours

Deprecating: colourMaybeDKG, fillMaybeDK, fillMaybePieceDK

Added (strict) makeRD, makeLD, makeRK, makeLK to Tgraph.Prelude


## version 1.2 -- 2024-12-1

Release candidate:
Introduced getDartInfoForced and improved performance of uncheckedPartCompose and uncheckedCompose
removed: composedFaces = snd . partComposeFaces  (all in Tgraph.Compose)

Significant improvement on space usage (fixing leaks)
adding StrictData to modules Tgraph.HalfTile, Tgraph.Compose, Tgraph.Force.
makeUncheckedTgraph now strictly evaluates its argument list of faces.

Made UpdateGenerator a newtype in Tgraph.Force

## 1.1.1 -- 2024-11-15

Exposed combineUpdateGenerators in Tgraph.Force

Reordered lists of faces in some basic example Tgraphs
(to ensure tails of the list are also valid as Tgraphs)

## 1.1.0 -- 2024-09-28

Release candidate: 

Added module CheckBackend with class OKBackend. This is really a class synonym for the constraints on a suitable Backend
for drawing tilings. Most types involving a backend b now have a constraint OKBackend b => ...

Removed type synonym: type Diagram2D b = QDiagram b V2 Double Any (no longer needed with the above constraint).

No longer exporting: differing, changeVFMap, forcedDecomp (= force . decompose).

Moved makeTgraph to Tgraph.Prelude.
Moved emplaceChoices to TgraphExamples and added example.
Moved module Tgraph.Try out of Tgraph (so now module Try).

tryStepForceWith now raises an error for negative number of steps.

Added graphBoundaryVs to Tgraph.Prelude.
Added tryBoundaryFaceGraph to Tgraphs

Made ForceState an instance of Show.

Improved haddock comments in Tgraph.Force.

Changed dash sizes for join edges (in dashjOnly).

## 1.0.0 -- 2024-04-08

Release candidate: 

Added upper bounds on dependencies

Added new drawEmpire and changed drawEmpire1, drawEmpire2 to showEmpire1, showEmpire2

## 0.10.0.0 -- 2024-04-1

Removed some examples in TgraphExamples and export of some auxiliary functions in Tgraph.Relabelling

## 0.9.1.0 -- 2024-03-12

Tgraph.Try as a separate module (instead of part of Tgraph.Prelude)
Added labelColourSize in DrawableLabelled with labelSize as special case
Changes to labelSize and line widths in some diagrams and drawing functions.
Removed labelSmall, labelLarge.
Added drawTrackedTgraphAligned.
Both restrictVP and relevantVP now check for missing locations.

## 0.8.0.2 -- 2024-02-25

Documentation changes only.

## 0.8.0.1 -- 2024-02-24

Fewer exported functions (Tgraph.Prelude, Tgraph.Relabelling), some renaming

## 0.7.0.0 -- 2024-02-18

Export of modules specified and changed (with more hiding)

## 0.6.0.0 -- 2024-02-17

Now as a standalone library

## 0.5.2.0 -- 2024-02-14

Added PKD (overall wrapper module).

## 0.5.1.0 -- 2024-02-13

Removed Tgraph.Convert (Conversions now included in Tgraph.Prelude)

## 0.5.0.0 -- 2024-01-26

(Removed ChosenBackEnd)
Only Main now imports a Backend (in preparation for creating library only).
Types have been generalised in modules that were previously using Backend B 
e.g.

    pCompFig :: Diagram B

has become

    pCompFig :: Renderable (Path V2 Double) b => Diagram2D b


## 0.4.0.0 -- 2023-10-27

Tgraphs now defined as newType

## 0.3.0.0 -- 2023-10-19

Modules: 
    src/
      HalfTile.hs              -- (Half)Tile constructors - used by TileLib and Tgraph.Prelude
      ChosenBackend.hs         -- switch between e.g. SVG or PostScript
      TileLib.hs               -- Drawing of Pieces (and Patches)
      Tgraphs.hs               -- Main Graph Ops (imports and reexports all modules in Tgraph and adds extra ops)
      Tgraph/
         Tgraph.Prelude.hs     -- (imports and reexports HalfTile)
         Tgraph.Decompose.hs
         Tgraph.Compose.hs
         Tgraph.Force.hs
         Tgraph.Convert.hs     -- Converting Tgraphs to VPatches (and drawing both)
      TgraphExamples.hs

## 0.2.0.0 -- 2022-03-31

Restructured modules

Graphs and Graph ops are collected in Tgraphs.hs
Converting functions (and VPatch definition) are in Tgraph.Convert.hs
Graph example figures are in TgraphExamples.hs

Original underlying Tile ops and tile drawing are in TileLib.hs

## 0.2.0.0 -- 2021-06-18

New Graph representations and operations on graphs (decomposeG, composeG, force, and more)
Tools to convert to Patches for drawing etc and also intermediate VPatches, to display Vertex information.

Key changes to original TileLib.hs : 

1.  New versions of tile halves using polymorphic versions of constructors in HalfTile.hs
2.  Pieces (replaces Components)
3.  Redefining Patches as a list of Located Pieces (Pieces with point position rather than an offset vector)
4.  Making Patches transformable (so that scale, rotate, translate can be used instead of specialised versions)

also fillDK became fillDK' with new version of fillDK

## 0.1.0.0 -- 2021-03-16

First version.
Vector representations and drawing tools for tile components and patches plus decompose and inflate operations.
Described in <https://readerunner.wordpress.com/2021/03/20/diagrams-for-penrose-tiles/>
